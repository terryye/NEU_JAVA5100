package edu.neu.mgen.HW9;

public class Student {
    public int id;
    public String firstName;
    public String lastName;

    public Student(int id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }
}
